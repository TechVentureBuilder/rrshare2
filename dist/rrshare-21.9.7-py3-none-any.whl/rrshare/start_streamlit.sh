#!/usr/bin/bash

killall streamlit 
#$(pgrep -af streamlit) 
streamlit run ~/rrshare/rrshare/rqWeb/stock_RS_OH_MA_to_streamlit.py







