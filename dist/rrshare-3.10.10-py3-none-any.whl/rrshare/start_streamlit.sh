#!/usr/bin/bash

killall streamlit 
#$(pgrep -af streamlit) 
/home/rome/.local/bin/streamlit run /home/rome/rrshare/rrshare/rqWeb/stock_RS_OH_MA_to_streamlit.py 








